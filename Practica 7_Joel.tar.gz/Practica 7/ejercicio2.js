window.onload = function(){
    document.getElementById('enlace').onclick = validar;
}

function validar(e){
    e.preventDefault();
}