window.onload = function(){
    window.onclick = function(){
        if(document.getElementsByTagName('button')){
            alert('has pulsado un boton');
        }
    }
}