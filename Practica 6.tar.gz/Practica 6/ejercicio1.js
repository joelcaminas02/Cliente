function mayor(elemento){
    elemento.style.fontSize="16pt";
}

function menor(elemento){
    elemento.style.fontSize="12pt";
}