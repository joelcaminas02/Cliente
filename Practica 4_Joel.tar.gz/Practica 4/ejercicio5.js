window.onload = function(){
  document.getElementsByTagName("p")[0].style.backgroundColor = '#006414';
  document.getElementsByTagName("p")[0].style.color = 'white';
}