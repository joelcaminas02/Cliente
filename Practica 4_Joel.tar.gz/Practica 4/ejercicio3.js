function azul(){
    document.getElementById('color').style.backgroundColor='blue';
}
function verde(){
    document.getElementById('color').style.backgroundColor='green';
}
function restaurar(){
    document.getElementById('color').style.backgroundColor='';
}